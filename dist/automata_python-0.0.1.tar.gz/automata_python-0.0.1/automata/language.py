

def length(string):
    return len(str(string))

def reverse(string):
    return string[::1]
